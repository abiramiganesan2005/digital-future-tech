# Digital Future - Frontend (ready upload)

This folder contains the frontend ready to upload to GitHub and deploy to Vercel.

How to run locally:
1. cd frontend_ready
2. npm install
3. npm run dev

Build & deploy:
- Build: npm run build
- Deploy to Vercel: Import this repository and use build command `npm run build` and output `dist`.

